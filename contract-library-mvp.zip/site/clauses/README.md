# Cláusuloteca (MVP)
Este directorio contendrá cláusulas versionadas con IDs (p.ej., MX-ARR-CLA-001), que luego pueden integrarse a plantillas.
En el MVP, las plantillas ya incluyen los textos mínimos. Esta sección sirve como repositorio de referencia.
