# Librería de Contratos · MVP (estático)

Este paquete contiene un sitio 100% estático para alojar una librería de contratos y un generador básico que rellena variables en plantillas Mustache y permite descargar el resultado como `.doc`.

## Estructura
```
site/
  index.html          # Catálogo + búsqueda simple
  generator.html      # Formulario + render + descarga .doc
  assets/styles.css   # Estilos
  data/templates.json # Metadatos de plantillas y variables
  templates/*.mustache# Plantillas Mustache
  clauses/            # (Opcional) Cláusuloteca en Markdown
```

## Cómo publicar gratis (GitHub Pages)
1. Crea un repositorio público en GitHub (p.ej., `contract-library`).
2. Sube el contenido de la carpeta `site/` a la raíz del repo.
3. Ve a Settings → Pages → Branch: `main` (root) → Save.
4. Espera a que se publique. Tu sitio quedará disponible con URL pública.

> Tip: Para añadir tu dominio, configura un CNAME en Pages y tus DNS.

## Cómo añadir/editar plantillas
1. Agrega un archivo `.mustache` en `templates/` con placeholders `{{variable}}`.
2. Declara sus variables en `data/templates.json` bajo el array `templates`.
3. Commitea y publica. El generador consumirá esos cambios automáticamente.

## Limitaciones del MVP
- Sin autenticación/roles.
- Descarga como `.doc` basado en HTML (Word-compatible), sin formato avanzado.
- Sin firma electrónica; integrar posteriormente con proveedores.

## Próximos pasos sugeridos
- Migrar a `.docx` o PDF con bibliotecas en navegador.
- Búsqueda avanzada con índices estáticos (Pagefind) o FlexSearch.
- Cláusuloteca modular con snippets reutilizables.
- Versionado SemVer + changelog de cada plantilla.
